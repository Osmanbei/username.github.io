const productsList = document.getElementById('FormSearch');
const searchBar = document.getElementById('searchBar');
let hpProducts = [];

searchBar.addEventListener('keyup', (e) => {
    const searchString = e.target.value.toLowerCase();

    const filteredProducts = hpProducts.filter((product) => {
        return (
            product.name.toLowerCase().includes(searchString)
        );
    });
    displayCharacters(filteredProducts);
});

const loadCharacters = async (
) => {
    try {
        const res = await fetch('http://localhost:3000/products');
        hpProducts = await res.json();
        displayCharacters(hpProducts);
    } catch (err) {
        console.error(err);
    }
};

const displayCharacters = (products) => {
    const htmlString = products
        .map((product) => {
            return `
            <div class="col-lg-3 col-md-6 mb-4">
          <div class="card">

            <div class="view overlay">
              <img class="card-img-top" src="${product.image}">
              <a href="${product.href}">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>

            <div class="card-body text-center">
              <h5>
                <strong>
                  <a href="${product.href}" class="dark-grey-text">${product.name} <span class="badge badge-pill ${product.span_color}-color">${product.span}</span></a>
                </strong>
              </h5>
              <h4 class="font-weight-bold green-text">
                <strong>${product.price}$</strong>
              </h4>
            </div>

          </div>
        </div>
        `;
        })
        .join('');
        
    productsList.innerHTML = htmlString;
};

loadCharacters();
