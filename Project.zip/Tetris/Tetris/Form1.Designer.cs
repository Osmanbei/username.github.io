﻿namespace Tetris
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.паузаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.начатьЗановоToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.справкаToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.менюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.PauseMusic = new System.Windows.Forms.ToolStripMenuItem();
            this.увеличитьПолеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.label3 = new System.Windows.Forms.Label();
            this.настройкиУровнейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.25F);
            this.label1.Location = new System.Drawing.Point(465, 204);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 35);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18.75F);
            this.label2.Location = new System.Drawing.Point(464, 254);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 37);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.паузаToolStripMenuItem1,
            this.начатьЗановоToolStripMenuItem1,
            this.справкаToolStripMenuItem1,
            this.менюToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(683, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // паузаToolStripMenuItem1
            // 
            this.паузаToolStripMenuItem1.Name = "паузаToolStripMenuItem1";
            this.паузаToolStripMenuItem1.Size = new System.Drawing.Size(64, 24);
            this.паузаToolStripMenuItem1.Text = "Пауза";
            this.паузаToolStripMenuItem1.Click += new System.EventHandler(this.OnPauseButtonClick);
            // 
            // начатьЗановоToolStripMenuItem1
            // 
            this.начатьЗановоToolStripMenuItem1.Name = "начатьЗановоToolStripMenuItem1";
            this.начатьЗановоToolStripMenuItem1.Size = new System.Drawing.Size(126, 24);
            this.начатьЗановоToolStripMenuItem1.Text = "Начать заново";
            this.начатьЗановоToolStripMenuItem1.Click += new System.EventHandler(this.OnAgainButtonClick);
            // 
            // справкаToolStripMenuItem1
            // 
            this.справкаToolStripMenuItem1.Name = "справкаToolStripMenuItem1";
            this.справкаToolStripMenuItem1.Size = new System.Drawing.Size(81, 24);
            this.справкаToolStripMenuItem1.Text = "Справка";
            this.справкаToolStripMenuItem1.Click += new System.EventHandler(this.OnInfoPressed);
            // 
            // менюToolStripMenuItem
            // 
            this.менюToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.PauseMusic,
            this.увеличитьПолеToolStripMenuItem,
            this.настройкиУровнейToolStripMenuItem});
            this.менюToolStripMenuItem.Name = "менюToolStripMenuItem";
            this.менюToolStripMenuItem.Size = new System.Drawing.Size(98, 24);
            this.менюToolStripMenuItem.Text = "Настройки";
            // 
            // PauseMusic
            // 
            this.PauseMusic.Name = "PauseMusic";
            this.PauseMusic.Size = new System.Drawing.Size(230, 26);
            this.PauseMusic.Text = "Выкл музыку";
            this.PauseMusic.Click += new System.EventHandler(this.PauseMusic_Click);
            // 
            // увеличитьПолеToolStripMenuItem
            // 
            this.увеличитьПолеToolStripMenuItem.Name = "увеличитьПолеToolStripMenuItem";
            this.увеличитьПолеToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.увеличитьПолеToolStripMenuItem.Text = "Настройки поля";
            this.увеличитьПолеToolStripMenuItem.Click += new System.EventHandler(this.увеличитьПолеToolStripMenuItem_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(468, 385);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "label3";
            // 
            // настройкиУровнейToolStripMenuItem
            // 
            this.настройкиУровнейToolStripMenuItem.Name = "настройкиУровнейToolStripMenuItem";
            this.настройкиУровнейToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.настройкиУровнейToolStripMenuItem.Text = "Настройки уровней";
            this.настройкиУровнейToolStripMenuItem.Click += new System.EventHandler(this.настройкиУровнейToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(683, 709);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = " ";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.OnPaint);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem менюToolStripMenuItem;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ToolStripMenuItem паузаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem начатьЗановоToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem справкаToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem PauseMusic;
        private System.Windows.Forms.ToolStripMenuItem увеличитьПолеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem настройкиУровнейToolStripMenuItem;
    }
}

