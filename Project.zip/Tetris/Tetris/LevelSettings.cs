﻿using System;
using System.Windows.Forms;
using Tetris.Controllers;

namespace Tetris
{
    public partial class LevelSettings : Form
    {
        public LevelSettings()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MapController.Interval = 300;
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MapController.Interval = 250;
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MapController.Interval = 200;
            Close();
        }
    }
}
