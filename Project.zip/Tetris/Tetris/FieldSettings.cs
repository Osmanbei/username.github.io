﻿using System;
using Tetris.Controllers;
using System.Windows.Forms;

namespace Tetris
{
    public partial class FieldSettings : Form
    {
        public FieldSettings()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MapController.FirstMapSize = 16;
            MapController.SecondMapSize = 8;
            MapController.ThirdMapSize = 7;

            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MapController.FirstMapSize = 18;
            MapController.SecondMapSize = 9;
            MapController.ThirdMapSize = 8;

            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MapController.FirstMapSize = 20;
            MapController.SecondMapSize = 10;
            MapController.ThirdMapSize = 9;

            Close();
        }
    }
}
