﻿using System;
using System.Windows.Forms;
using Tetris.Controllers;

namespace Tetris
{
    public partial class Records : Form
    {
        public Records()
        {
            InitializeComponent();
            RecordsController.ShowRecords(label1);
        }
        private void Records_Load(object sender, EventArgs e)
        {

        }
    }
}
